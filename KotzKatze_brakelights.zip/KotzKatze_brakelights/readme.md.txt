SCRIPT BY:
KotzKatze

just drag and drop it in yyou scripts aka. ressources folder restart the server and finnished
while you are staning your brakelights will automaticly be on so it's more realistic!