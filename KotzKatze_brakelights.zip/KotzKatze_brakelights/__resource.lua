
resource_manifest_version '44febabe-d386-4d18-afbe-5e627f4af937'

name 'BrakeLights'
description 'Makes brake lights show when a vehicle is stopped!'
author 'KotzKatze'
version '1.0.2'

client_script 'cl_lights.lua'